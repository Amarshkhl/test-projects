<?php
   session_start();

   //connect to db
   $db = mysqli_connect("localhost", "root", "", "Foodie");
   $firstname_error="";
   $lastname_error="";
   $email_error="";
   $phone_error="";
   $message="";
   $msg="";
    $closeicon= 'hideicon';
   if(isset($_POST['register'])) {
      $firstname =trim($_POST['FirstName']);
      $lastname =trim($_POST['LastName']);
      $email = trim($_POST['Email']);
      $phone = trim($_POST['Phone']);

      if(empty($firstname)){
        $firstname_error ="Please enter your firstname";
      }
      if(empty($lastname)){
        $lastname_error ="Please enter your lastname";
      }
      if (empty($email)) {
          $email_error = "Email is required";
       } else {
         // check if e-mail address is well-formed
         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
           $email_error = "Invalid email format"; 
         }
       }
      if(empty($phone)){
        $phone_error ="Please enter your phone number";
      } else {
         // check if valid phone number
        if(!preg_match("/^[0-9]{10}+$/", $phone)) {
           $phone_error = "Please enter number between 10 digits"; 
         }
       }
      $sql = "INSERT INTO users(FirstName, LastName, Email, Phone) VALUES('$firstname','$lastname','$email','$phone')";
      $result = mysqli_query($db, $sql);
      if($result== true){
        $message = "Thank you for the registration";
        $msg = 'alert alert-success fade in';
        $firstname="";
        $lastname="";
        $email="";
        $phone="";
        $closeicon= 'showicon';
        
      }
      else{
        $message ="Something is wrong, Please submit again";
        $msg = 'alert alert-danger fade in';
        $closeicon= 'showicon';
      }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Foodie</title>
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
  <body>
    <header id="header">
      <div class="container">
        <nav class="navbar navbar-default">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#"><img src="images/logo.png" width="120" height="30" alt="foodie logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="index.html">Home <span class="sr-only">(current)</span></a></li>
                <li><a href="#">Members</a></li>
                <li><a href="#">Gallery</a></li>
                <li><a href="#">About Us</a></li>
              </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>
      </div>
    </header>
    <main id="main">
      <div class="container">
        <section class="main-content">
          <h1>In Food we indulge</h1>
          <p>Some of our members' uploads</p>
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
              <div class="item active">
                <img src="images/img-1.jpg" alt="foodie">
              </div>
              <div class="item">
                <img src="images/img-2.jpg" alt="foodie">
              </div>
              <div class="item">
                <div class="embed-responsive embed-responsive-16by9">
                  <iframe class="embed-responsive-item" width="560" height="315" src="https://www.youtube.com/embed/tAjTSeT_1pw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
              </div>
              <div class="item">
                <img src="images/img-1.jpg" alt="foodie">
              </div>
              <div class="item">
                <img src="images/img-2.jpg" alt="foodie">
              </div>
              <div class="item">
                <div class="embed-responsive embed-responsive-16by9">
                  <iframe class="embed-responsive-item" width="560" height="315" src="https://www.youtube.com/embed/tAjTSeT_1pw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
              </div>
            </div>

            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </section>
        <div class="row">
          <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
            <section class="join-us">
              <h2>Share your food pictures.</h2>
              <h3>Join us:</h3>
              <div class="<?php echo $msg;?>"><?php echo $message;?>               
                <div class="<?php echo $closeicon;?>">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                </div>
              </div>
              <form class="join-form" method = "post" action="index.php">
                <fieldset>  
                  <div class="form-group">
                    <label for="element-1">First Name</label>
                    <input type="text" id="element-1" class="form-control" name="FirstName" required value="<?php echo isset($firstname) ? $firstname : "" ?>">
                    <span class="error"><?php echo $firstname_error; ?></span>
                  </div>
                  <div class="form-group">
                    <label for="element-2">Last Name</label>
                    <input type="text" id="element-2" class="form-control" name="LastName" required value="<?php echo isset($lastname) ? $lastname : "" ?>"">
                     <span class="error"><?php echo $lastname_error; ?></span>
                  </div>
                  <div class="form-group">
                    <label for="element-3">Email</label>
                    <input type="text" id="element-3" class="form-control" name="Email" required value="<?php echo isset($email) ? $email: "" ?>">
                     <span class="error"><?php echo $email_error; ?></span>
                  </div>
                  <div class="form-group">
                    <label for="element-4">Phone number</label>
                    <input type="number" id="element-4" class="form-control phone"  name="Phone" required value="<?php echo isset($phone)? $phone: "" ?>">
                     <span class="error"><?php echo $phone_error; ?></span>
                  </div>
                  <button type="submit" class="btn btn-success" name="register">Submit</button>
                </fieldset>
              </form>
            </section>
          </div>
        </div>
      </div>
    </main>
    <footer id="footer">
      <ul class="social-networks">
        
      </ul>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
 /**Custom Script **/
 (function( $ ) {
    $(window).scroll(function(){
      scroll = $(window).scrollTop();

  if (scroll >= 60){
    $('#header').addClass('fixed');
  } 
  else {
    $('#header').removeClass('fixed');
  }
});
  
})( jQuery );
    </script>
  </body>
</html>